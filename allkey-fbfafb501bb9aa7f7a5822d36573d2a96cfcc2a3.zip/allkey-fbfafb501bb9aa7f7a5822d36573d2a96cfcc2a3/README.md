# List of all Bitcoin addresses addressed

This is simple, proof-of-concept project main purpose of which, better understainding of Bitcoin address system. Feel free to play around with it :)

Big thanks to:  
**@ntieman** and his [StringMath.js](https://github.com/ntieman/StringMath.js) library, without it this project had no chances to be completed.  
**@OutCast3k** and his [coinbin](https://github.com/OutCast3k/coinbin) project, which helped me get better understnding of address generating process.  
**Blockchain.info** (com, whatever) for actually providing [API](https://www.blockchain.com/api/blockchain_api) for multiple address info and balances :D
